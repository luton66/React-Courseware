import React from 'react';

export function Footer() {
  return (
      <footer>
        Made for fans by a fan
      </footer>
  );
}
