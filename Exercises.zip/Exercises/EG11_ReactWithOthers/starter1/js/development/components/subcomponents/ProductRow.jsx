import React from 'react';

export default class ProductRow extends React.Component {
  render() {

    return (
      <tr>
        <td>Name</td>
        <td>Price</td>
      </tr>
    );
  }
}
